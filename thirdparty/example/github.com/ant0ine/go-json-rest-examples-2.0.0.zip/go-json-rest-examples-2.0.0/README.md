Examples for go-json-rest
=========================

**Go-Json-Rest** is a thin layer on top of `net/http` that helps building RESTful JSON APIs easily.
See the Github repo here: https://github.com/ant0ine/go-json-rest

Copyright (c) 2013-2014 Antoine Imbert

[MIT License](https://github.com/ant0ine/go-json-rest-examples/blob/master/LICENSE)

[![Analytics](https://ga-beacon.appspot.com/UA-309210-4/go-json-rest-examples/v2-alpha/readme)](https://github.com/igrigorik/ga-beacon)
